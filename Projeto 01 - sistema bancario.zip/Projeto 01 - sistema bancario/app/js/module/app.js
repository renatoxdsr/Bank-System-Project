let clienteController = new ClienteController();
clienteController.listar();
const c1 = new Cliente('Valenço', '10036224599', '269958');
//const p1 = new Poupanca('2', 100);
//const cb1 = new ContaBonificada('3', 0);
console.log('Nome: ' + c1.nome, 'CPF:' + c1.cpf, 'Conta:' + c1.conta);
//p1.atualizarConta();
//console.log('Conta: ' + p1.conta);
